<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class placecon extends Controller
{
    public function placeconnew(){

    return view('placnew');

    }
}
