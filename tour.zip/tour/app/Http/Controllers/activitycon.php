<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class activitycon extends Controller
{
    public function activityew(){

        return view('activitys');
    
        }
}
