<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class vehiclecon extends Controller
{
    public function vehiclenew(){

        return view('vahiclenew');
    
        }
}
