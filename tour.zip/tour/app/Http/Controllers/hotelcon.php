<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class hotelcon extends Controller
{
    public function hotelsnew(){

        return view('hotel');
    
        }
}
