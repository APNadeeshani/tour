<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class activitys extends Model
{
    //
}
