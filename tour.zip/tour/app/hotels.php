<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class hotels extends Model
{
    //
}
