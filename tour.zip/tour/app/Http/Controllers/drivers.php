<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class drivers extends Controller
{
    
    public function drivnew(){

        return view('drivernew');
    }
}
